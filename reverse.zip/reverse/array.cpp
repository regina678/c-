#include<iostream>

using namespace std;

void reverseArray(int arr[], int n) {
  std::reverse(arr, arr + n);
}

int main() {
    int arr[] = {10, 23, 3, 16, 7};
    int n = sizeof(arr) / sizeof(arr[0]);
    std::cout << "Original array: ";
    for (int i = 0; i < n; i++) {
        std::cout << arr[i] << " ";
         }
         std::cout << std::endl;
         reverseArray(arr, n);
         std::cout << "Reversed array: ";
         for (int i = 0; i < n; i++) {
            std::cout << arr[i] << " ";
            }
            std::cout << std::endl;
             return 0;
}